# My first program in R Programming
myString <- "Hello, World!"

print ( myString)

console.log("Hello World!")
var toto = function(name) {
	return 'hello '+name;
}
